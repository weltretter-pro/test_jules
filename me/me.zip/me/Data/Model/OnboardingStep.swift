struct OnboardingStep {
    let imageName: String
    let title: String
    let description: String
}
