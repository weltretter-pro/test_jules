import SwiftUI
struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(isUserAuthenticated: .constant(false))
    }
}
