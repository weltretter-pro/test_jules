import SwiftUI

struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    @State private var isShowingSettings = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    
                    if let mission = viewModel.currentMission {
                        MissionCardView(mission: mission)
                        
                        HStack(spacing: 15) {
                            PrimaryButton(title: "Accept Mission", action: {})
                            SecondaryButton(title: "Skip", action: {
                                viewModel.fetchNewMission()
                            })
                        }
                        .padding(.horizontal)
                        
                        PrimaryButton(title: "Add Mission", action: {}).padding(.horizontal)
                        
                    } else {
                        Text("No missions available for this age group.")
                            .padding()
                    }
                }
            }
            .navigationTitle("Home")
            .navigationBarItems(trailing: Button(action: {
                isShowingSettings.toggle()
            }) {
                Image(systemName: "gearshape.fill")
                    .font(.title2)
                    .foregroundColor(.primary)
            })
            .sheet(isPresented: $isShowingSettings) {
                SettingsView()
            }
        }
    }
}
